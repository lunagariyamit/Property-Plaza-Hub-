import './App.css';
import { Apartment } from './pages/Apartment';
import Home from './pages/home';


function App() {
  return (
    <>
      <Home />
      
    </>
  );
}



export default App;
